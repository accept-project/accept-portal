
w["language"]= "16,25";
w["later"]= "7,10";
w["law"]= "2";
w["let"]= "7";
w["leverage"]= "25";
w["license"]= "2";
w["light"]= "9";
w["list"]= "16,25";
w["lists"]= "22";

