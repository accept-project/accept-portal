
w["generates"]= "25";
w["generator"]= "7";
w["germany"]= "2";
w["getting"]= "10";
w["gives"]= "24";
w["gmbh"]= "2";
w["grammar"]= "9,16,25";
w["green"]= "9,22";
w["guarantee"]= "2";
w["guide"]= "3,4,11,12,18,20";

