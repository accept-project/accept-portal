
w["want"]= "16";
w["was"]= "9,25";
w["ways"]= "8";
w["web"]= "7,8";
w["website"]= "2";
w["when"]= "5,7,9,16,18,24,25";
w["which"]= "16,25";
w["who"]= "4,25";
w["whole"]= "24";
w["window"]= "7,8";
w["with"]= "8,14,20,21,23,24,25,26,27";
w["within"]= "2,22";
w["without"]= "2,24";
w["words"]= "9,25";
w["working"]= "14,26,27";
w["works"]= "10";
w["writing"]= "2,25";
w["written"]= "2";
w["www"]= "2";

