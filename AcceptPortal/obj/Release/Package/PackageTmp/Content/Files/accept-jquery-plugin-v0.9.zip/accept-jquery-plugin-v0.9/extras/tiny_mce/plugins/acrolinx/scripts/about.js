var AboutDialog = {
    init : function(o) {
        function setText(id,val) {
            document.getElementById(id).innerHTML = val;
        }
        
        var sdkVersionInfo =  tinyMCEPopup.getWindowArg('acrolinx').sdkVersionInfo;
        var versionInfo =  tinyMCEPopup.getWindowArg('versionInfo');
        
        setText('version',versionInfo.version);
        setText('buildNumber',versionInfo.buildNumber);
        setText('sdkVersion',sdkVersionInfo.version);
        setText('sdkBuildNumber',sdkVersionInfo.buildNumber);
        
    },

    ok : function() {
        tinyMCEPopup.close();
    }
};

tinyMCEPopup.onInit.add(AboutDialog.init, AboutDialog);
