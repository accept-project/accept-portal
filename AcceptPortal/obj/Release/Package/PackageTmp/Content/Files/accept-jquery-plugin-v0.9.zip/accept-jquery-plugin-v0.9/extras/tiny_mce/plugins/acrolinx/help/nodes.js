
	
USETEXTLINKS = 1
STARTALLOPEN = 0
HIGHLIGHT = 1
HIGHLIGHT_BG = '#cccccc'
HIGHLIGHT_COLOR = '#000000'

foldersTree = gFld("", "")
  foldersTree.treeID = "Frameset"  
  
	
	


aux1 = insFld(foldersTree, gFld(" Copyright Notice","acrolinx_IQ_Plug-ins/shared_plugins/Copyright_Notice.html"))

aux1 = insFld(foldersTree, gFld(" Overview","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Introduction.html"))

	aux2 = insFld(aux1, gFld("About this Guide","acrolinx_IQ_Plug-ins/shared_plugins/common_content/About_this_Guide.html"))
		insDoc(aux2, gLnk("R", "Purpose","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Purpose.html"))
		insDoc(aux2, gLnk("R", "Audience","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Audience.html"))
		insDoc(aux2, gLnk("R", "Terms Used","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Terms_Used.html"))

aux1 = insFld(foldersTree, gFld(" The Acrolinx IQ Plug-in on Your System","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Plug-in_on_Your_System.html"))
	insDoc(aux1, gLnk("R", "Starting the Acrolinx IQ Plug-in","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Starting_the_acrolinx_IQ_Plug-in.html"))
	insDoc(aux1, gLnk("R", "The Acrolinx IQ Toolbar","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Toolbar.html"))
	insDoc(aux1, gLnk("R", "The Acrolinx IQ Commands","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Commands.html"))
	insDoc(aux1, gLnk("R", "The Acrolinx IQ Version Information Dialog Box","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinxIQ_About_Dialog.html"))

aux1 = insFld(foldersTree, gFld(" Getting Ready to Check","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Getting_Ready_to_Check.html"))
	insDoc(aux1, gLnk("R", "Setting the Checking Options","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Setting_the_Checking_Options.html"))

aux1 = insFld(foldersTree, gFld(" Checking Documents","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Checking_Documents.html"))
	insDoc(aux1, gLnk("R", "Checking a Document","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Checking_a_Document.html"))
	insDoc(aux1, gLnk("R", "The Acrolinx IQ Results Dialog Box","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Results_Dialog_Box.html"))

aux1 = insFld(foldersTree, gFld(" Reviewing and Correcting Checked Text","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Reviewing_and_Correcting_Checked_Documents.html"))
	insDoc(aux1, gLnk("R", "Flag Colors","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Flag_Colors.html"))

	aux2 = insFld(aux1, gFld("Working with Flags","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Working_with_Flags.html"))

		aux3 = insFld(aux2, gFld("The Shortcut Menu","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_Shortcut_Menu.html"))
			insDoc(aux3, gLnk("R", "Editing Flags with the Shortcut Menu","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Editing_Flags_with_the_Shortcut_Menu.html"))
		insDoc(aux2, gLnk("R", "Removing Flags from a Document","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Removing_Flags_from_a_Document.html"))
	insDoc(aux1, gLnk("R", "Saving and Closing Documents","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Saving_and_Closing_Documents.html"))

aux1 = insFld(foldersTree, gFld(" Working with Checking Reports","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Working_with_Checking_Reports.html"))
	insDoc(aux1, gLnk("R", "Using the Checking Report","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Using_the_Checking_Report.html"))
	insDoc(aux1, gLnk("R", "Displaying a Checking Report","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Displaying_a_Checking_Report.html"))
