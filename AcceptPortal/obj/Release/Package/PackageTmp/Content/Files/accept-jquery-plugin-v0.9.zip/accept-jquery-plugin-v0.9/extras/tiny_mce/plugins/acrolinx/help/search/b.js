
w["be"]= "2,4,7";
w["becomes"]= "9";
w["been"]= "16";
w["before"]= "10,20";
w["berlin"]= "2";
w["beside"]= "22";
w["between"]= "2";
w["blue"]= "9";
w["box"]= "5,6,19,21,22";
w["brown"]= "9";
w["browser"]= "7,8";
w["but"]= "22";
w["button"]= "7,13,16,19,20";
w["buttons"]= "20,23";
w["by"]= "2,4,7,8,19,25";

