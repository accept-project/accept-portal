
	
USETEXTLINKS = 1
STARTALLOPEN = 0
HIGHLIGHT = 1
HIGHLIGHT_BG = '#cccccc'
HIGHLIGHT_COLOR = '#000000'

foldersTree = gFld("index", "")
  foldersTree.treeID = "Frameset"  
  
	
	



			aux1 = insFld(foldersTree, gFld("A", ""))
					
						aux2 = insFld(aux1, gFld("About this     Guide","acrolinx_IQ_Plug-ins/shared_plugins/common_content/About_this_Guide.html#D201"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Adding a Word to a Spelling Dictionary","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_Shortcut_Menu.html#D2426"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Audience","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Audience.html#D2418"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("C", ""))
					
						aux2 = insFld(aux1, gFld("Checking a Document","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Checking_a_Document.html#D249"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Checking Documents","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Checking_Documents.html#D241"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Contributing Terms to the Terminology Database","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_Shortcut_Menu.html#D2426"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("D", ""))
					
						aux2 = insFld(aux1, gFld("Displaying a Checking Report","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Displaying_a_Checking_Report.html#D273"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("E", ""))
					
						aux2 = insFld(aux1, gFld("Editing Flags with the Shortcut Menu","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Editing_Flags_with_the_Shortcut_Menu.html#D5530"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("F", ""))
					
						aux2 = insFld(aux1, gFld("Flag Colors","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Flag_Colors.html#D5282"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("G", ""))
					
						aux2 = insFld(aux1, gFld("Getting Ready to Check","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Getting_Ready_to_Check.html#D202"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("I", ""))
					
						aux2 = insFld(aux1, gFld("Introduction","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Introduction.html#D108"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("P", ""))
					
						aux2 = insFld(aux1, gFld("Purpose","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Purpose.html#D2410"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("R", ""))
					
						aux2 = insFld(aux1, gFld("Removing Flags from a Document","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Removing_Flags_from_a_Document.html#D2420"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Reviewing and Correcting Checked Text","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Reviewing_and_Correcting_Checked_Documents.html#D255"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("S", ""))
					
						aux2 = insFld(aux1, gFld("Saving and Closing     Documents","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Saving_and_Closing_Documents.html#D270"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Setting and     Changing Flag Colors","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Flag_Colors.html#D5282"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					
 
		aux2 = insFld(aux1, gFld("Setting the Checking Options",""))
		
			insDoc(aux2, gLnk("R", "Setting the Checking Options","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Setting_the_Checking_Options.html#D305"))
		
			insDoc(aux2, gLnk("R", "Setting the Checking Options","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Checking_a_Document.html#D249"))
		


						aux2 = insFld(aux1, gFld("Setting the Menu Position","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Editing_Flags_with_the_Shortcut_Menu.html#D5530"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Shortcut Keys","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Commands.html#D1538"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Starting the Acrolinx IQ Plug-in","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Starting_the_acrolinx_IQ_Plug-in.html#Starting_the_acrolinx_IQ_Plug-in"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("T", ""))
					
						aux2 = insFld(aux1, gFld("Terms Used","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Terms_Used.html#D2411"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("The Acrolinx IQ     Toolbar","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Commands.html#D1538"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					
 
		aux2 = insFld(aux1, gFld("The Acrolinx IQ Commands",""))
		
			insDoc(aux2, gLnk("R", "The Acrolinx IQ Commands","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Commands.html#D1538"))
		
			insDoc(aux2, gLnk("R", "The Acrolinx IQ Commands","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Toolbar.html#D1978"))
		


						aux2 = insFld(aux1, gFld("The Acrolinx IQ Menu","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Commands.html#D1538"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("The Acrolinx IQ Plug-in on Your System","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Plug-in_on_Your_System.html#D203"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					
 
		aux2 = insFld(aux1, gFld("The Acrolinx IQ Results Dialog Box",""))
		
			insDoc(aux2, gLnk("R", "The Acrolinx IQ Results Dialog Box","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Results_Dialog_Box.html#D5596"))
		
			insDoc(aux2, gLnk("R", "The Acrolinx IQ Results Dialog Box","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Checking_a_Document.html#D249"))
		


						aux2 = insFld(aux1, gFld("The Acrolinx IQ Toolbar","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinx_IQ_Toolbar.html#D1978"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("The Acrolinx IQ Version Information Dialog Box","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_acrolinxIQ_About_Dialog.html#D5156"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("The Shortcut Menu","acrolinx_IQ_Plug-ins/shared_plugins/common_content/The_Shortcut_Menu.html#D2426"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

			aux1 = insFld(foldersTree, gFld("U", ""))
					 
		aux2 = insFld(aux1, gFld("Using the Checking Report",""))
		
			insDoc(aux2, gLnk("R", "Using the Checking Report","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Using_the_Checking_Report.html#D272"))
		
			insDoc(aux2, gLnk("R", "Using the Checking Report","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Displaying_a_Checking_Report.html#D273"))
		


			aux1 = insFld(foldersTree, gFld("W", ""))
					
						aux2 = insFld(aux1, gFld("Working with     Flags","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Working_with_Flags.html#D259"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					

						aux2 = insFld(aux1, gFld("Working with Checking     Reports","acrolinx_IQ_Plug-ins/shared_plugins/common_content/Working_with_Checking_Reports.html#D271"))
						aux2.iconSrc = ICONPATH + "ftv2doc.gif" 
						aux2.iconSrcClosed = ICONPATH + "ftv2doc.gif"
					


