tinyMCE.addI18n((tinymce.settings.language || 'en') + '.acrolinx', {
    button_check : 'Check the text and highlight any issues with colored flags',
    button_help : 'Help',
    button_options: 'Specify checking options before checking the text',
    button_report: 'See the checking report',
    button_about: 'See information about the version of the Acrolinx IQ Plug-in that you are using',
    'button_remove-flags': 'Remove Flags',
});

tinyMCE.addI18n((tinymce.settings.language || 'en')+'.acrolinx_dlg',{
    title : 'Acrolinx IQ Options',
    about_title: 'Acrolinx IQ Version Information !',
    checking_progress_title: 'Acrolinx IQ Check Progress',
    check_results_title: 'Acrolinx IQ Results',
    ok: 'OK'
});