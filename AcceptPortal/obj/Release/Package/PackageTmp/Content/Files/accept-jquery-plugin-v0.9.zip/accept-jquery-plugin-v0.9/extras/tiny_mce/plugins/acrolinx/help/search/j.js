
w["jump"]= "25";

