
w["ideal"]= "22";
w["identified"]= "16";
w["identify"]= "16";
w["if"]= "2,5,7,10,16,17,24,25";
w["ignore"]= "8,24";
w["included"]= "23";
w["includes"]= "25";
w["inconsistent"]= "25";
w["indicate"]= "9";
w["indicates"]= "18,22,25";
w["information"]= "2,7,19,20,21,24,25";
w["informing"]= "25";
w["installation"]= "16";
w["installed"]= "7,17";
w["intellectual"]= "2";
w["intended"]= "4";
w["iq"]= "2,4,5,6,7,10,12,13,16,17,18,19,20,21,22,23,24,25";
w["issue"]= "9,18,24,25";
w["issues"]= "16,19,24,25";
w["it"]= "2,5,7,9,15,17";
w["item"]= "8,24";
w["items"]= "8,24";

