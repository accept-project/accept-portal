var CheckingProgressDialog = {
        
    init : function(o) {
        var jQuery =  tinyMCEPopup.getWindowArg('jQuery');
        var setCheckProgressMonitor =  tinyMCEPopup.getWindowArg('setCheckProgressMonitor');
        var getLatestCheckStatus =  tinyMCEPopup.getWindowArg('getLatestCheckStatus');
        this.cancelCheck =  tinyMCEPopup.getWindowArg('cancelCheck');

        function calcProgressPercentage(checkStatus) {
            if (checkStatus.state === 'RUNNING_PROCESSING') {
                return checkStatus.percentCurrentRunningPhase;
            } else if (checkStatus.state === 'RUNNING_POSTPROCESSING' || checkStatus.state === 'DONE') {
                return 100;
            } else {
                return 0;
            }
        };
        
        function setProgressBarPercentage(percentage) {
            jQuery('.acrolinxProgressBar .acrolinxProgressBarValue',document).css('width', Math.max(percentage, 5) + '%');
        }
        
        setCheckProgressMonitor(function(checkStatus){
            if (checkStatus.state === 'DONE') {
                tinyMCEPopup.close();
            } else {
                setProgressBarPercentage(calcProgressPercentage(checkStatus));
            }
        });

        var latestCheckStatus = getLatestCheckStatus();
        if (latestCheckStatus && latestCheckStatus.state === 'DONE') {
            // ups to late...
            tinyMCEPopup.close();
        }
        
    },

    cancel : function() {
        this.cancelCheck();
        tinyMCEPopup.close();
    }
};

tinyMCEPopup.onInit.add(CheckingProgressDialog.init, CheckingProgressDialog);
