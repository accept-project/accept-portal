var CheckResultsDialog = {
        
    init : function(o) {
        var jQuery =  tinyMCEPopup.getWindowArg('jQuery');
        this.onOk =  tinyMCEPopup.getWindowArg('onOk');
        this.onCancel =  tinyMCEPopup.getWindowArg('onCancel');
        var checkResultsView =  tinyMCEPopup.getWindowArg('checkResultsView');
        jQuery('#checkResultsViewContainer',window.document).empty().append(checkResultsView);
    },

    ok : function() {
        this.onOk();
        tinyMCEPopup.close();
    },
    
    cancel : function() {
        this.onCancel();
        tinyMCEPopup.close();
    }
};

tinyMCEPopup.onInit.add(CheckResultsDialog.init, CheckResultsDialog);
