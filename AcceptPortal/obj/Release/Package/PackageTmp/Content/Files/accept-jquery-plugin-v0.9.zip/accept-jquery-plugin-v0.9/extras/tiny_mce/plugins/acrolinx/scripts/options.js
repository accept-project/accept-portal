var OptionsDialog = {
    init : function(o) {
        var self = this;
        var iqServerFacade = tinyMCEPopup.getWindowArg('iqServerFacade');
        var currentUser =  tinyMCEPopup.getWindowArg('currentUser');
        var currentCheckSettings =  tinyMCEPopup.getWindowArg('currentCheckSettings');
        window.jQuery =  tinyMCEPopup.getWindowArg('jQuery');
        window.acrolinx =  tinyMCEPopup.getWindowArg('acrolinx');

        iqServerFacade.getPersonalizedUserService(currentUser, acrolinx.io.createAsyncCallback(function(personalizedUserService) {
            function onError(error) {
                alert(error);
            }

            var optionsForm = acrolinx.ui
                    .createOptionsForm(iqServerFacade, new acrolinx.ui.OptionsFormListener(onError), currentCheckSettings, {}, personalizedUserService);

            jQuery('#optionsFormContainer',window.document).empty().append(optionsForm.htmlElement);
            
            self.optionsForm = optionsForm;
        }));

    },

    ok : function() {
        var currentCheckSettings = this.optionsForm.getCheckSettings();
        tinyMCEPopup.editor.execCommand('acrolinx-setCheckSettings', false,currentCheckSettings);
        tinyMCEPopup.close();
    }
};

tinyMCEPopup.onInit.add(OptionsDialog.init, OptionsDialog);
