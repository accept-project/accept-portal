
w["occurrence"]= "25";
w["occurrences"]= "24";
w["of"]= "2,8,9,16,18,20,22,24,25";
w["office"]= "2";
w["ok"]= "5,16";
w["olive"]= "9";
w["on"]= "2,4,7,21,24,25";
w["one"]= "8,16,24";
w["only"]= "16,25";
w["open"]= "7,18,19";
w["optimization"]= "25";
w["option"]= "16,24,25";
w["optional"]= "16,25";
w["options"]= "5,10,16,20";
w["or"]= "2,4,7,8,16,18,25";
w["orange"]= "9";
w["order"]= "25";
w["organization"]= "4,25";
w["other"]= "8";
w["others"]= "7,25";
w["outside"]= "7";
w["overall"]= "25";
w["overview"]= "11,25";
w["owners"]= "2";

