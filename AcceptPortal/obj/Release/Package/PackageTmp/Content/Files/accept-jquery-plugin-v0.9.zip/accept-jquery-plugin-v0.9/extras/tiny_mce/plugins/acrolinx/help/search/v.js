
w["valid"]= "9,16,25";
w["validated"]= "25";
w["value"]= "25";
w["version"]= "19,20,21,25";
w["view"]= "7";

